
cis 519 - v1 2022-04-26 5:44pm
==============================

This dataset was exported via roboflow.ai on April 26, 2022 at 9:45 PM GMT

It includes 473 images.
Poly-yolo are annotated in YOLO v3 (Keras) format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

The following augmentation was applied to create 3 versions of each source image:

The following transformations were applied to the bounding boxes of each image:
* Random brigthness adjustment of between -25 and +25 percent


